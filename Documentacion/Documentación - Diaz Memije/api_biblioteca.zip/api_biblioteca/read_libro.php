<?php
include 'config.php';

$id = $_GET['id'];

$sql = "SELECT * FROM Libros WHERE ID_libro = $id";
$result = $conn->query($sql);

if ($row = $result->fetch_assoc()) {
    echo json_encode($row);
} else {
    echo json_encode(["error" => "Libro no encontrado"]);
}
?>
