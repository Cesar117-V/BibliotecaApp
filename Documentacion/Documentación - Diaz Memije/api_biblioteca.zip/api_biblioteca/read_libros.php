<?php
include 'config.php';

$sql = "SELECT * FROM Libros";
$result = $conn->query($sql);

$libros = [];

while ($row = $result->fetch_assoc()) {
    $libros[] = $row;
}

echo json_encode($libros);
?>
