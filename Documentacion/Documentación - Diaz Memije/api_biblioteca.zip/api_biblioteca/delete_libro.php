<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"));
$id = $data->ID_libro;

$sql = "DELETE FROM Libros WHERE ID_libro = $id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["mensaje" => "Libro eliminado"]);
} else {
    echo json_encode(["error" => $conn->error]);
}
?>
