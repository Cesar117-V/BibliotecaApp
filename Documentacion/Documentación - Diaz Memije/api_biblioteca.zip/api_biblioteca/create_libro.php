<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"));

$titulo = $data->Titulo;
$descripcion = $data->Descripcion;
$imagen = $data->Imagen;
$id_categoria = $data->ID_categoria;
$id_autor = $data->ID_autor;
$num_paginas = $data->Num_paginas;
$num_adquisicion = $data->Num_adquisicion;
$cantidad_ejemplares = $data->Cantidad_ejemplares;

$sql = "INSERT INTO Libros (Titulo, Descripcion, Imagen, ID_categoria, ID_autor, Num_paginas, Num_adquisicion, Cantidad_ejemplares)
        VALUES ('$titulo', '$descripcion', '$imagen', $id_categoria, $id_autor, $num_paginas, '$num_adquisicion', $cantidad_ejemplares)";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["mensaje" => "Libro creado correctamente"]);
} else {
    echo json_encode(["error" => $conn->error]);
}
?>
