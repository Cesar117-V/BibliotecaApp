<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"));

$id = $data->ID_libro;
$titulo = $data->Titulo;
$descripcion = $data->Descripcion;
$imagen = $data->Imagen;
$id_categoria = $data->ID_categoria;
$id_autor = $data->ID_autor;
$num_paginas = $data->Num_paginas;
$num_adquisicion = $data->Num_adquisicion;
$cantidad_ejemplares = $data->Cantidad_ejemplares;

$sql = "UPDATE Libros SET 
    Titulo='$titulo',
    Descripcion='$descripcion',
    Imagen='$imagen',
    ID_categoria=$id_categoria,
    ID_autor=$id_autor,
    Num_paginas=$num_paginas,
    Num_adquisicion='$num_adquisicion',
    Cantidad_ejemplares=$cantidad_ejemplares
    WHERE ID_libro=$id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["mensaje" => "Libro actualizado correctamente"]);
} else {
    echo json_encode(["error" => $conn->error]);
}
?>
