<?php
$host = "127.0.0.1";
$puerto = "3307";
$usuario = "root";
$contrasena = "";
$bd = "biblioteca";

$conn = new mysqli($host, $usuario, $contrasena, $bd, $puerto);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
